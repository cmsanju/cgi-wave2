## Getting Started with JavaScript Unit Testing Using Mocha

Code to accompany the following article: http://www.sitepoint.com/unit-test-javascript-mocha-chai

To run the code samples:

- Clone the repo
- Run `npm install`
- Open `testrunner.html` in browser
- Alternatively, uncomment Node specific code and run `mocha` from the command line (this requires Mocha to be installed globally).

License MIT
